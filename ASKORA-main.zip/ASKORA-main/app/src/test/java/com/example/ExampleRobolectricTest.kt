package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.Converters
import com.example.model.Citation
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("ASKORA", appName)
    }

    @Test
    fun `test converters serialization with android json`() {
        val converters = Converters()
        val citations = listOf(
            Citation(
                id = "c1",
                index = 1,
                title = "Test Paper",
                url = "https://askora.ai",
                domain = "askora.ai",
                snippet = "Testing snippet"
            )
        )
        val json = converters.fromCitations(citations)
        val deserialized = converters.toCitations(json)
        assertEquals(1, deserialized.size)
        assertEquals("Test Paper", deserialized[0].title)
    }
}
