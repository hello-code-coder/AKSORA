package com.example

import com.example.data.AskoraAiEngine
import com.example.data.PromptModifier
import com.example.model.AnswerDepth
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testAskoraAiEngine_generatesSimpleDepth() = runBlocking {
        val engine = AskoraAiEngine()
        val response = engine.finalizeResponse("Explain quantum computing simply", AnswerDepth.SIMPLE)
        assertNotNull(response.fullText)
        assertTrue(response.fullText.contains("Quantum"))
        assertTrue(response.citations.isNotEmpty())
    }

    @Test
    fun testAskoraAiEngine_generatesBalancedDepthWithCode() = runBlocking {
        val engine = AskoraAiEngine()
        val response = engine.finalizeResponse("Explain quantum computing", AnswerDepth.BALANCED)
        assertNotNull(response.fullText)
        assertTrue(response.citations.isNotEmpty())
        assertTrue(response.verifiedFacts.isNotEmpty())
    }

    @Test
    fun testAskoraAiEngine_handlesSimplifyModifier() = runBlocking {
        val engine = AskoraAiEngine()
        val response = engine.finalizeResponse("Any complex concept", AnswerDepth.BALANCED, PromptModifier.SIMPLIFY)
        assertTrue(response.fullText.contains("In Plain Words"))
    }
}
