package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        ConversationEntity::class,
        ChatMessageEntity::class,
        SavedAnswerEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AskoraDatabase : RoomDatabase() {
    abstract fun askoraDao(): AskoraDao

    companion object {
        @Volatile
        private var INSTANCE: AskoraDatabase? = null

        fun getDatabase(context: Context): AskoraDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AskoraDatabase::class.java,
                    "askora_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
