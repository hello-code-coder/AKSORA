package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.LuminousCyan
import com.example.ui.theme.MidnightDarker
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

@Composable
fun MarkdownView(
    content: String,
    modifier: Modifier = Modifier
) {
    val lines = content.lines()
    var i = 0

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        while (i < lines.size) {
            val line = lines[i]

            // Check for code blocks ```
            if (line.trim().startsWith("```")) {
                val lang = line.trim().removePrefix("```").trim().ifEmpty { "CODE" }
                val codeBuilder = StringBuilder()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) {
                    codeBuilder.append(lines[i]).append("\n")
                    i++
                }
                CodeBlockView(
                    code = codeBuilder.toString().trimEnd(),
                    language = lang,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                i++
                continue
            }

            // Check for Markdown table
            if (line.trim().startsWith("|") && line.trim().endsWith("|")) {
                val tableLines = mutableListOf<String>()
                while (i < lines.size && lines[i].trim().startsWith("|") && lines[i].trim().endsWith("|")) {
                    tableLines.add(lines[i])
                    i++
                }
                MarkdownTable(tableLines)
                continue
            }

            // Check for Headings
            when {
                line.startsWith("### ") -> {
                    Text(
                        text = line.removePrefix("### ").trim(),
                        color = LuminousCyan,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
                    )
                }
                line.startsWith("## ") -> {
                    Text(
                        text = line.removePrefix("## ").trim(),
                        color = LuminousCyan,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
                    )
                }
                line.startsWith("# ") -> {
                    Text(
                        text = line.removePrefix("# ").trim(),
                        color = TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                    )
                }
                line.trim().startsWith("- ") || line.trim().startsWith("* ") -> {
                    val itemText = line.trim().substring(2)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 4.dp, top = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(top = 7.dp)
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(VioletAccent)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = parseInlineFormatting(itemText),
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            color = TextPrimary
                        )
                    }
                }
                line.trim().matches(Regex("^\\d+\\.\\s.*")) -> {
                    val parts = line.trim().split(Regex("^(\\d+)\\.\\s"), 2)
                    val num = line.trim().takeWhile { it.isDigit() }
                    val itemText = if (parts.size > 1) parts[1] else line.trim()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 4.dp, top = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "$num.",
                            color = LuminousCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(22.dp)
                        )
                        Text(
                            text = parseInlineFormatting(itemText),
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            color = TextPrimary
                        )
                    }
                }
                line.trim().startsWith("> ") -> {
                    val quote = line.trim().removePrefix("> ")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(SurfaceElevated.copy(alpha = 0.6f))
                            .border(1.dp, VioletAccent.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(20.dp)
                                .background(LuminousCyan)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = parseInlineFormatting(quote),
                            fontSize = 13.sp,
                            fontStyle = FontStyle.Italic,
                            lineHeight = 18.sp,
                            color = TextSecondary
                        )
                    }
                }
                line.isNotBlank() -> {
                    Text(
                        text = parseInlineFormatting(line),
                        fontSize = 14.sp,
                        lineHeight = 21.sp,
                        color = TextPrimary
                    )
                }
            }
            i++
        }
    }
}

@Composable
private fun MarkdownTable(tableLines: List<String>) {
    if (tableLines.size < 2) return

    val headers = tableLines[0].split("|")
        .map { it.trim() }
        .filter { it.isNotEmpty() }

    val dataRows = tableLines.drop(1)
        .filter { line -> !line.contains("---") } // remove markdown separator row
        .map { row ->
            row.split("|").map { it.trim() }.filter { it.isNotEmpty() }
        }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
            .background(MidnightDarker)
            .horizontalScroll(rememberScrollState())
            .padding(8.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            // Header Row
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(SurfaceElevated)
                    .padding(vertical = 6.dp, horizontal = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                headers.forEach { header ->
                    Text(
                        text = header.replace("**", ""),
                        color = LuminousCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(110.dp)
                    )
                }
            }

            // Data Rows
            dataRows.forEach { row ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp, horizontal = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    row.forEach { cell ->
                        Text(
                            text = cell.replace("**", ""),
                            color = TextSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.width(110.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun parseInlineFormatting(text: String): androidx.compose.ui.text.AnnotatedString {
    return buildAnnotatedString {
        // Regex to parse bold **text**, inline code `code`, and citations [1]
        var cursor = 0
        val regex = Regex("(\\*\\*.*?\\*\\*|`.*?`|\\[\\d+\\])")
        val matches = regex.findAll(text)

        for (match in matches) {
            val range = match.range
            if (range.first > cursor) {
                append(text.substring(cursor, range.first))
            }
            val matchText = match.value
            when {
                matchText.startsWith("**") && matchText.endsWith("**") -> {
                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, color = TextPrimary)) {
                        append(matchText.removeSurrounding("**"))
                    }
                }
                matchText.startsWith("`") && matchText.endsWith("`") -> {
                    withStyle(
                        style = SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            color = LuminousCyan,
                            background = SurfaceElevated
                        )
                    ) {
                        append(" ${matchText.removeSurrounding("`")} ")
                    }
                }
                matchText.matches(Regex("\\[\\d+\\]")) -> {
                    withStyle(
                        style = SpanStyle(
                            color = LuminousCyan,
                            fontWeight = FontWeight.Bold
                        )
                    ) {
                        append(matchText)
                    }
                }
                else -> {
                    append(matchText)
                }
            }
            cursor = range.last + 1
        }
        if (cursor < text.length) {
            append(text.substring(cursor))
        }
    }
}
