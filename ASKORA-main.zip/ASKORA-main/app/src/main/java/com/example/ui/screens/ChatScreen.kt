package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.AnswerDepth
import com.example.model.ChatMessage
import com.example.model.MessageRole
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.components.AnswerActionRow
import com.example.ui.components.CitationsSection
import com.example.ui.components.ComposerBar
import com.example.ui.components.DepthSelectorRow
import com.example.ui.components.GlassCard
import com.example.ui.components.MarkdownView
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.LuminousCyan
import com.example.ui.theme.MidnightDarker
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.SurfaceHighlight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val activeConv by viewModel.activeConversation.collectAsState()
    val messages by viewModel.activeMessages.collectAsState()
    val isStreaming by viewModel.isStreaming.collectAsState()
    val selectedDepth by viewModel.selectedDepth.collectAsState()
    val isSpeaking by viewModel.tts.isSpeaking.collectAsState()

    var composerText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Auto-scroll on new message or streaming
    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MidnightNavy,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = activeConv?.title ?: "AI Conversation",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${activeConv?.provider?.displayName ?: "Askora Neo"} • Zero Hallucination Mode",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    // Quick depth selector in topbar
                    DepthSelectorRow(
                        selectedDepth = selectedDepth,
                        onDepthSelected = { viewModel.setDepth(it) },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    IconButton(onClick = { viewModel.startNewConversation() }) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "New chat",
                            tint = LuminousCyan
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        },
        bottomBar = {
            ComposerBar(
                queryText = composerText,
                onQueryChange = { composerText = it },
                onSend = { uri, name ->
                    val query = composerText
                    composerText = ""
                    viewModel.submitQuery(
                        prompt = query,
                        depth = selectedDepth,
                        attachmentUri = uri,
                        attachmentName = name
                    )
                },
                onVoiceClick = { viewModel.navigateTo(Screen.VOICE) },
                selectedDepth = selectedDepth,
                onDepthClick = {
                    val nextDepth = when (selectedDepth) {
                        AnswerDepth.SIMPLE -> AnswerDepth.BALANCED
                        AnswerDepth.BALANCED -> AnswerDepth.DEEP
                        AnswerDepth.DEEP -> AnswerDepth.SIMPLE
                    }
                    viewModel.setDepth(nextDepth)
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(messages, key = { it.id }) { message ->
                ChatMessageItem(
                    message = message,
                    isSpeaking = isSpeaking,
                    onReadAloud = { viewModel.tts.speak(message.content) },
                    onStopReading = { viewModel.tts.stop() },
                    onToggleSave = { viewModel.toggleSave(message) },
                    onRegenerate = { viewModel.regenerateAnswer(message) },
                    onFeedback = { helpful -> viewModel.setFeedback(message.id, helpful) },
                    onModifierClick = { modifier -> viewModel.applyPromptModifier(message, modifier) }
                )
            }

            if (isStreaming && messages.none { it.isStreaming }) {
                item {
                    StreamingIndicator()
                }
            }
        }
    }
}

@Composable
fun ChatMessageItem(
    message: ChatMessage,
    isSpeaking: Boolean,
    onReadAloud: () -> Unit,
    onStopReading: () -> Unit,
    onToggleSave: () -> Unit,
    onRegenerate: () -> Unit,
    onFeedback: (Boolean) -> Unit,
    onModifierClick: (com.example.data.PromptModifier) -> Unit
) {
    val isUser = message.role == MessageRole.USER

    if (isUser) {
        // User Message Bubble
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp))
                    .background(SurfaceHighlight)
                    .border(1.dp, VioletAccent.copy(alpha = 0.35f), RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp))
                    .padding(14.dp)
            ) {
                // If attachment is present
                if (message.attachmentName != null || message.attachmentUri != null) {
                    Row(
                        modifier = Modifier
                            .padding(bottom = 8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MidnightDarker)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (message.attachmentUri != null) {
                            AsyncImage(
                                model = message.attachmentUri,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(RoundedCornerShape(4.dp))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        } else {
                            Icon(
                                imageVector = Icons.Default.AttachFile,
                                contentDescription = null,
                                tint = LuminousCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = message.attachmentName ?: "Attachment",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }

                Text(
                    text = message.content,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    lineHeight = 22.sp
                )
            }
        }
    } else {
        // Assistant Message Card
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(LuminousCyan.copy(alpha = 0.18f))
                    .border(1.dp, LuminousCyan.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = LuminousCyan,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                // Main Content Card
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(4.dp, 20.dp, 20.dp, 20.dp),
                    backgroundColor = SurfaceElevated.copy(alpha = 0.95f),
                    borderColor = GlassBorder
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        // Depth Tag
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(LuminousCyan.copy(alpha = 0.12f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${message.depth.label} Answer",
                                    color = LuminousCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (message.isStreaming) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    CircularProgressIndicator(
                                        color = LuminousCyan,
                                        modifier = Modifier.size(12.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Text(
                                        text = "Synthesizing...",
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        // Rich Markdown & Code & Tables
                        MarkdownView(content = message.content)

                        // Citations Section if citations exist
                        if (message.citations.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            CitationsSection(citations = message.citations)
                        }
                    }
                }

                // Controls row for the answer
                if (!message.isStreaming && message.content.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    AnswerActionRow(
                        message = message,
                        isSpeaking = isSpeaking,
                        onReadAloud = onReadAloud,
                        onStopReading = onStopReading,
                        onToggleSave = onToggleSave,
                        onRegenerate = onRegenerate,
                        onFeedback = onFeedback,
                        onModifierClick = onModifierClick
                    )
                }
            }
        }
    }
}

@Composable
fun StreamingIndicator() {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceElevated)
            .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        CircularProgressIndicator(
            color = LuminousCyan,
            modifier = Modifier.size(14.dp),
            strokeWidth = 2.dp
        )
        Text(
            text = "ASKORA is reasoning & verifying facts...",
            color = TextSecondary,
            fontSize = 12.sp
        )
    }
}
