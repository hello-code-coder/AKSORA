package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CosmicPurple
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.LuminousCyan
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.VioletAccent
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class OrbState {
    IDLE, LISTENING, STREAMING, THINKING
}

@Composable
fun AiOrb(
    modifier: Modifier = Modifier,
    size: Dp = 180.dp,
    state: OrbState = OrbState.IDLE,
    onClick: (() -> Unit)? = null
) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrbTransitions")

    // Rotation angle for cosmic swirls
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    OrbState.STREAMING, OrbState.LISTENING -> 4000
                    OrbState.THINKING -> 2500
                    OrbState.IDLE -> 9000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Reverse slow rotation for secondary ring
    val reverseRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "reverseRotation"
    )

    // Pulsing aura scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = when (state) {
            OrbState.STREAMING -> 1.12f
            OrbState.LISTENING -> 1.18f
            OrbState.THINKING -> 1.08f
            OrbState.IDLE -> 1.03f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    OrbState.STREAMING -> 1200
                    OrbState.LISTENING -> 800
                    else -> 2400
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Interactive tap bounce effect
    val bounceAnim = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .size(size)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                enabled = onClick != null
            ) {
                scope.launch {
                    bounceAnim.animateTo(0.88f, tween(100))
                    bounceAnim.animateTo(1f, tween(250, easing = FastOutSlowInEasing))
                }
                onClick?.invoke()
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = (this.size.minDimension / 2f) * 0.72f * pulseScale * bounceAnim.value

            // 1. Deep ambient celestial glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        CyanGlow.copy(alpha = 0.28f),
                        VioletAccent.copy(alpha = 0.16f),
                        CosmicPurple.copy(alpha = 0.06f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.6f
                ),
                radius = baseRadius * 1.6f,
                center = center
            )

            // 2. Soft outer plasma field
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        LuminousCyan.copy(alpha = 0.45f),
                        VioletAccent.copy(alpha = 0.35f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.15f
                ),
                radius = baseRadius * 1.15f,
                center = center
            )

            // 3. Deep inner core orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        MidnightNavy,
                        Color(0xFF0F1A30),
                        ElectricIndigo.copy(alpha = 0.8f),
                        LuminousCyan.copy(alpha = 0.9f)
                    ),
                    center = Offset(center.x - baseRadius * 0.2f, center.y - baseRadius * 0.25f),
                    radius = baseRadius
                ),
                radius = baseRadius,
                center = center
            )

            // 4. Rotating cosmic crescent wave (matches the visual artifact swirl in reference screenshot)
            rotate(rotationAngle, pivot = center) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            Color.Transparent,
                            LuminousCyan.copy(alpha = 0.85f),
                            CyanGlow,
                            VioletAccent.copy(alpha = 0.7f),
                            Color.Transparent
                        ),
                        center = center
                    ),
                    startAngle = 30f,
                    sweepAngle = 240f,
                    useCenter = false,
                    topLeft = Offset(center.x - baseRadius * 0.95f, center.y - baseRadius * 0.95f),
                    size = Size(baseRadius * 1.9f, baseRadius * 1.9f),
                    style = Stroke(width = baseRadius * 0.16f, cap = StrokeCap.Round)
                )

                // Internal light filaments
                drawArc(
                    brush = Brush.linearGradient(
                        colors = listOf(LuminousCyan, VioletAccent)
                    ),
                    startAngle = 180f,
                    sweepAngle = 120f,
                    useCenter = false,
                    topLeft = Offset(center.x - baseRadius * 0.65f, center.y - baseRadius * 0.65f),
                    size = Size(baseRadius * 1.3f, baseRadius * 1.3f),
                    style = Stroke(width = baseRadius * 0.08f, cap = StrokeCap.Round)
                )
            }

            // 5. Counter-rotating elliptical orbital halo
            rotate(reverseRotation, pivot = center) {
                drawOval(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            Color.Transparent,
                            VioletAccent.copy(alpha = 0.6f),
                            LuminousCyan.copy(alpha = 0.4f),
                            Color.Transparent
                        ),
                        center = center
                    ),
                    topLeft = Offset(center.x - baseRadius * 1.25f, center.y - baseRadius * 0.7f),
                    size = Size(baseRadius * 2.5f, baseRadius * 1.4f),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // 6. Brilliant luminous crescent highlight on top-right edge (signature glass orb look)
            drawArc(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.95f),
                        LuminousCyan.copy(alpha = 0.8f),
                        Color.Transparent
                    ),
                    start = Offset(center.x + baseRadius * 0.2f, center.y - baseRadius * 0.9f),
                    end = Offset(center.x + baseRadius * 0.9f, center.y)
                ),
                startAngle = -80f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = Offset(center.x - baseRadius * 0.88f, center.y - baseRadius * 0.88f),
                size = Size(baseRadius * 1.76f, baseRadius * 1.76f),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )

            // 7. Ambient audio pulse ripples when listening or streaming
            if (state == OrbState.LISTENING || state == OrbState.STREAMING) {
                val rippleRadius = baseRadius * (1.25f + 0.35f * ((rotationAngle % 180f) / 180f))
                val rippleAlpha = (1f - ((rotationAngle % 180f) / 180f)).coerceIn(0f, 0.7f)
                drawCircle(
                    color = LuminousCyan.copy(alpha = rippleAlpha * 0.5f),
                    radius = rippleRadius,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }
}
