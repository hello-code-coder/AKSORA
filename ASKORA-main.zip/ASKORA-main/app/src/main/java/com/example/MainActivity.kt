package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ResearchScreen
import com.example.ui.screens.SavedAnswersScreen
import com.example.ui.screens.SubscriptionScreen
import com.example.ui.screens.VoiceScreen
import com.example.ui.theme.AskoraTheme
import com.example.ui.theme.MidnightNavy

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AskoraTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MidnightNavy
                ) {
                    val viewModel: MainViewModel = viewModel()
                    AskoraApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun AskoraApp(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
        when (screen) {
            Screen.HOME -> HomeScreen(viewModel = viewModel)
            Screen.CHAT -> ChatScreen(viewModel = viewModel)
            Screen.RESEARCH -> ResearchScreen(viewModel = viewModel)
            Screen.VOICE -> VoiceScreen(viewModel = viewModel)
            Screen.SAVED -> SavedAnswersScreen(viewModel = viewModel)
            Screen.HISTORY -> HistoryScreen(viewModel = viewModel)
            Screen.PROFILE -> ProfileScreen(viewModel = viewModel)
            Screen.SUBSCRIPTION -> SubscriptionScreen(viewModel = viewModel)
            Screen.ONBOARDING -> OnboardingScreen(viewModel = viewModel)
        }
    }
}
