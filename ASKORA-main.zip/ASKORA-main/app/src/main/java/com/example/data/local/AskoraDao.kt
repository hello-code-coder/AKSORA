package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AskoraDao {
    // Conversations
    @Query("SELECT * FROM conversations ORDER BY isPinned DESC, updatedAt DESC")
    fun getAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    suspend fun getConversationById(id: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: ConversationEntity)

    @Update
    suspend fun updateConversation(conversation: ConversationEntity)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversation(id: String)

    @Query("DELETE FROM conversations")
    suspend fun clearAllConversations()

    // Messages
    @Query("SELECT * FROM chat_messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: String): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Update
    suspend fun updateMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages WHERE conversationId = :conversationId")
    suspend fun deleteMessagesForConversation(conversationId: String)

    @Query("DELETE FROM chat_messages")
    suspend fun clearAllMessages()

    @Query("UPDATE chat_messages SET isSaved = :isSaved WHERE id = :id")
    suspend fun setMessageSaved(id: String, isSaved: Boolean)

    @Query("UPDATE chat_messages SET feedback = :feedback WHERE id = :id")
    suspend fun setMessageFeedback(id: String, feedback: Boolean?)

    // Saved answers
    @Query("SELECT * FROM saved_answers ORDER BY savedAt DESC")
    fun getAllSavedAnswers(): Flow<List<SavedAnswerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedAnswer(saved: SavedAnswerEntity)

    @Query("DELETE FROM saved_answers WHERE id = :id")
    suspend fun deleteSavedAnswer(id: String)

    @Query("DELETE FROM saved_answers WHERE messageId = :messageId")
    suspend fun deleteSavedAnswerByMessageId(messageId: String)

    @Query("DELETE FROM saved_answers")
    suspend fun clearAllSavedAnswers()
}
