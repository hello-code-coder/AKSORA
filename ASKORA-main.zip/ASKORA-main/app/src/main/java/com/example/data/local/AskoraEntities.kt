package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.example.model.AnswerDepth
import com.example.model.Citation
import com.example.model.CodeSnippet
import com.example.model.MessageRole
import com.example.model.ModelProviderType
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val snippet: String,
    val updatedAt: Long,
    val messageCount: Int,
    val isPinned: Boolean,
    val depth: String,
    val provider: String
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String,
    val content: String,
    val timestamp: Long,
    val depth: String,
    val citationsJson: String,
    val codeBlocksJson: String,
    val isStreaming: Boolean = false,
    val isSaved: Boolean = false,
    val feedback: Boolean? = null,
    val attachmentName: String? = null,
    val attachmentUri: String? = null
)

@Entity(tableName = "saved_answers")
data class SavedAnswerEntity(
    @PrimaryKey val id: String,
    val messageId: String,
    val title: String,
    val summary: String,
    val content: String,
    val tagsJson: String,
    val citationsCount: Int,
    val savedAt: Long
)

class Converters {
    @TypeConverter
    fun fromCitations(citations: List<Citation>): String {
        val jsonArray = JSONArray()
        citations.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("index", c.index)
            obj.put("title", c.title)
            obj.put("url", c.url)
            obj.put("domain", c.domain)
            obj.put("snippet", c.snippet)
            obj.put("isVerifiedFact", c.isVerifiedFact)
            obj.put("credibilityScore", c.credibilityScore)
            jsonArray.put(obj)
        }
        return jsonArray.toString()
    }

    @TypeConverter
    fun toCitations(data: String?): List<Citation> {
        if (data.isNullOrBlank()) return emptyList()
        val list = mutableListOf<Citation>()
        try {
            val jsonArray = JSONArray(data)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    Citation(
                        id = obj.optString("id"),
                        index = obj.optInt("index", i + 1),
                        title = obj.optString("title"),
                        url = obj.optString("url"),
                        domain = obj.optString("domain"),
                        snippet = obj.optString("snippet"),
                        isVerifiedFact = obj.optBoolean("isVerifiedFact", true),
                        credibilityScore = obj.optInt("credibilityScore", 95)
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    @TypeConverter
    fun fromCodeBlocks(codeBlocks: List<CodeSnippet>): String {
        val jsonArray = JSONArray()
        codeBlocks.forEach { snippet ->
            val obj = JSONObject()
            obj.put("language", snippet.language)
            obj.put("code", snippet.code)
            jsonArray.put(obj)
        }
        return jsonArray.toString()
    }

    @TypeConverter
    fun toCodeBlocks(data: String?): List<CodeSnippet> {
        if (data.isNullOrBlank()) return emptyList()
        val list = mutableListOf<CodeSnippet>()
        try {
            val jsonArray = JSONArray(data)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    CodeSnippet(
                        language = obj.optString("language"),
                        code = obj.optString("code")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    @TypeConverter
    fun fromStringList(list: List<String>): String {
        val jsonArray = JSONArray()
        list.forEach { jsonArray.put(it) }
        return jsonArray.toString()
    }

    @TypeConverter
    fun toStringList(data: String?): List<String> {
        if (data.isNullOrBlank()) return emptyList()
        val list = mutableListOf<String>()
        try {
            val jsonArray = JSONArray(data)
            for (i in 0 until jsonArray.length()) {
                list.add(jsonArray.getString(i))
            }
        } catch (_: Exception) {}
        return list
    }
}
