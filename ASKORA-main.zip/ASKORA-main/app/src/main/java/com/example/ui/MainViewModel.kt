package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AskoraAiEngine
import com.example.data.AskoraRepository
import com.example.data.PromptModifier
import com.example.data.TextToSpeechHelper
import com.example.data.local.AskoraDatabase
import com.example.model.AnswerDepth
import com.example.model.ChatMessage
import com.example.model.Conversation
import com.example.model.ModelProviderType
import com.example.model.SavedAnswer
import com.example.model.SubscriptionPlan
import com.example.model.UserProfile
import com.example.model.WebResearchSynthesis
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class Screen {
    HOME, CHAT, RESEARCH, VOICE, SAVED, HISTORY, PROFILE, SUBSCRIPTION, ONBOARDING
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AskoraDatabase.getDatabase(application)
    private val engine = AskoraAiEngine()
    val repository = AskoraRepository(database.askoraDao(), engine)
    val tts = TextToSpeechHelper(application)

    // Navigation State
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenBackStack = mutableListOf<Screen>()

    // Current Active Conversation
    private val _activeConversation = MutableStateFlow<Conversation?>(null)
    val activeConversation: StateFlow<Conversation?> = _activeConversation.asStateFlow()

    private val _activeMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val activeMessages: StateFlow<List<ChatMessage>> = _activeMessages.asStateFlow()

    // Answer Depth
    private val _selectedDepth = MutableStateFlow(AnswerDepth.BALANCED)
    val selectedDepth: StateFlow<AnswerDepth> = _selectedDepth.asStateFlow()

    // Streaming state
    private val _isStreaming = MutableStateFlow(false)
    val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

    // User Profile
    val userProfile: StateFlow<UserProfile> = repository.userProfile

    // Conversations & Saved Answers from Room DB
    val conversations: StateFlow<List<Conversation>> = repository.allConversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedAnswers: StateFlow<List<SavedAnswer>> = repository.allSavedAnswers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Research State
    private val _activeResearch = MutableStateFlow<WebResearchSynthesis?>(null)
    val activeResearch: StateFlow<WebResearchSynthesis?> = _activeResearch.asStateFlow()

    private val _isResearching = MutableStateFlow(false)
    val isResearching: StateFlow<Boolean> = _isResearching.asStateFlow()

    // Voice State
    private val _voiceTranscript = MutableStateFlow("")
    val voiceTranscript: StateFlow<String> = _voiceTranscript.asStateFlow()

    private val _isVoiceListening = MutableStateFlow(false)
    val isVoiceListening: StateFlow<Boolean> = _isVoiceListening.asStateFlow()

    private var activeStreamJob: Job? = null
    private var activeMessagesJob: Job? = null

    init {
        // Pre-populate welcome conversation if none exists
        viewModelScope.launch {
            conversations.collect { list ->
                if (list.isEmpty()) {
                    createDefaultWelcomeConversation()
                }
            }
        }
    }

    private suspend fun createDefaultWelcomeConversation() {
        val welcomeConv = repository.getOrCreateConversation(
            id = "welcome-conv-1",
            initialTitle = "Welcome to ASKORA"
        )
        _activeConversation.value = welcomeConv
        repository.sendUserMessage(
            conversationId = welcomeConv.id,
            content = "How can ASKORA help me understand complex questions?"
        )
        repository.streamAssistantResponse(
            conversationId = welcomeConv.id,
            prompt = "How can ASKORA help me understand complex questions?",
            depth = AnswerDepth.BALANCED
        ) {}
    }

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            screenBackStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenBackStack.isNotEmpty()) {
            _currentScreen.value = screenBackStack.removeAt(screenBackStack.size - 1)
            return true
        } else if (_currentScreen.value != Screen.HOME) {
            _currentScreen.value = Screen.HOME
            return true
        }
        return false
    }

    fun setDepth(depth: AnswerDepth) {
        _selectedDepth.value = depth
    }

    fun openConversation(conversation: Conversation) {
        _activeConversation.value = conversation
        _selectedDepth.value = conversation.depth
        observeMessages(conversation.id)
        navigateTo(Screen.CHAT)
    }

    fun startNewConversation() {
        viewModelScope.launch {
            val conv = repository.getOrCreateConversation(null, "New Inquiry")
            _activeConversation.value = conv
            observeMessages(conv.id)
            navigateTo(Screen.CHAT)
        }
    }

    private fun observeMessages(conversationId: String) {
        activeMessagesJob?.cancel()
        activeMessagesJob = viewModelScope.launch {
            repository.getMessages(conversationId).collect { msgs ->
                _activeMessages.value = msgs
            }
        }
    }

    fun submitQuery(
        prompt: String,
        depth: AnswerDepth = _selectedDepth.value,
        attachmentUri: String? = null,
        attachmentName: String? = null
    ) {
        if (prompt.isBlank()) return

        viewModelScope.launch {
            var currentConv = _activeConversation.value
            if (currentConv == null) {
                currentConv = repository.getOrCreateConversation(null, prompt.take(30))
                _activeConversation.value = currentConv
                observeMessages(currentConv.id)
            }

            // Navigate to chat screen if not already there
            if (_currentScreen.value != Screen.CHAT) {
                navigateTo(Screen.CHAT)
            }

            repository.sendUserMessage(
                conversationId = currentConv.id,
                content = prompt,
                depth = depth,
                attachmentName = attachmentName,
                attachmentUri = attachmentUri
            )

            // Trigger streaming response
            _isStreaming.value = true
            activeStreamJob?.cancel()
            activeStreamJob = launch {
                try {
                    repository.streamAssistantResponse(
                        conversationId = currentConv.id,
                        prompt = prompt,
                        depth = depth
                    ) { partial ->
                        // partial update handled in repo
                    }
                } finally {
                    _isStreaming.value = false
                }
            }
        }
    }

    fun applyPromptModifier(message: ChatMessage, modifier: PromptModifier) {
        val conv = _activeConversation.value ?: return
        viewModelScope.launch {
            _isStreaming.value = true
            activeStreamJob?.cancel()
            activeStreamJob = launch {
                try {
                    repository.streamAssistantResponse(
                        conversationId = conv.id,
                        prompt = message.content,
                        depth = message.depth,
                        modifier = modifier
                    ) {}
                } finally {
                    _isStreaming.value = false
                }
            }
        }
    }

    fun regenerateAnswer(message: ChatMessage) {
        applyPromptModifier(message, PromptModifier.REGENERATE)
    }

    fun toggleSave(message: ChatMessage) {
        viewModelScope.launch {
            repository.toggleSaveMessage(message)
        }
    }

    fun setFeedback(messageId: String, helpful: Boolean) {
        viewModelScope.launch {
            repository.setFeedback(messageId, helpful)
        }
    }

    fun togglePinConversation(conversation: Conversation) {
        viewModelScope.launch {
            repository.togglePinConversation(conversation)
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            repository.deleteConversation(id)
            if (_activeConversation.value?.id == id) {
                _activeConversation.value = null
                _activeMessages.value = emptyList()
                navigateBack()
            }
        }
    }

    // Web Deep Research Execution
    fun executeWebResearch(topic: String) {
        if (topic.isBlank()) return
        viewModelScope.launch {
            _isResearching.value = true
            navigateTo(Screen.RESEARCH)

            // Simulate multi-step research crawler & fact synthesis
            kotlinx.coroutines.delay(2200)

            val synthesis = WebResearchSynthesis(
                query = topic,
                executiveSummary = "Comprehensive multi-domain web synthesis on '$topic'. Data indexed across technical repositories, academic publications, and verified news wires with strict hallucination-free consensus checks.",
                verifiedFindings = listOf(
                    "Standardized protocols emphasize modular zero-trust verification.",
                    "Latency across edge inference nodes benchmarked below 24ms.",
                    "Peer-reviewed metrics validate the consistency of deterministic pipelines."
                ),
                uncertainties = listOf(
                    "Regulatory frameworks across cross-border compute clusters are pending harmonization.",
                    "Long-term cost amortization for multi-terawatt datacenter infrastructure."
                ),
                citations = listOf(
                    com.example.model.Citation(
                        id = "res-c1",
                        index = 1,
                        title = "Global Technology Horizon & Research Index",
                        url = "https://askora.ai/research/$topic",
                        domain = "research.askora.ai",
                        snippet = "Systematic analysis of empirical evidence, benchmarks, and architectural consensus.",
                        isVerifiedFact = true,
                        credibilityScore = 99
                    ),
                    com.example.model.Citation(
                        id = "res-c2",
                        index = 2,
                        title = "MIT Tech Review: Frontiers of Discovery",
                        url = "https://technologyreview.com/topic/$topic",
                        domain = "technologyreview.com",
                        snippet = "Benchmarking real-world deployments and verified industry transformations.",
                        isVerifiedFact = true,
                        credibilityScore = 97
                    )
                ),
                completenessScore = 96
            )

            _activeResearch.value = synthesis
            _isResearching.value = false

            // Increment profile stats
            repository.updateUserProfile {
                it.copy(
                    deepResearchCount = it.deepResearchCount + 1,
                    queriesUsed = it.queriesUsed + 1
                )
            }
        }
    }

    // Voice mode triggers
    fun setVoiceListening(listening: Boolean) {
        _isVoiceListening.value = listening
        if (listening) {
            _voiceTranscript.value = "Listening to your voice inquiry..."
        }
    }

    fun submitVoiceQuery(spokenText: String) {
        _voiceTranscript.value = spokenText
        _isVoiceListening.value = false
        submitQuery(spokenText)
    }

    fun updateProfile(update: (UserProfile) -> UserProfile) {
        repository.updateUserProfile(update)
    }

    fun purgeUserData() {
        viewModelScope.launch {
            repository.purgeAllUserData()
            _activeConversation.value = null
            _activeMessages.value = emptyList()
            _activeResearch.value = null
            _currentScreen.value = Screen.HOME
        }
    }

    fun upgradePlan(plan: SubscriptionPlan) {
        viewModelScope.launch {
            repository.upgradeSubscription(plan)
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts.shutdown()
        activeStreamJob?.cancel()
        activeMessagesJob?.cancel()
    }
}
