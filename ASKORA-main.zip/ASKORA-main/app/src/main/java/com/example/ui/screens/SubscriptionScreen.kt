package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SubscriptionPlan
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.LuminousCyan
import com.example.ui.theme.MidnightDarker
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.SurfaceHighlight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VerifiedFactGreen
import com.example.ui.theme.VioletAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val userProfile by viewModel.userProfile.collectAsState()
    var isAnnual by remember { mutableStateOf(true) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MidnightNavy,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "ASKORA Membership",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Banner
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.linearGradient(
                            listOf(LuminousCyan, VioletAccent)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = null,
                    tint = MidnightNavy,
                    modifier = Modifier.size(34.dp)
                )
            }

            Text(
                text = "Boundless Intelligence",
                color = TextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Experience uninterrupted streaming, deep web synthesis, zero hallucination citations, and priority reasoning.",
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                lineHeight = 19.sp
            )

            // Billing Cycle Switcher (Monthly / Annual)
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BillingOptionPill("Monthly", !isAnnual) { isAnnual = false }
                BillingOptionPill("Annual (Save 20%)", isAnnual) { isAnnual = true }
            }

            // Subscription Tiers Cards
            PlanCard(
                plan = SubscriptionPlan.FREE,
                price = if (isAnnual) SubscriptionPlan.FREE.priceAnnual else SubscriptionPlan.FREE.priceMonthly,
                isCurrent = userProfile.plan == SubscriptionPlan.FREE,
                features = listOf(
                    "Standard response latency",
                    "Askora Neo 2.5 baseline model",
                    "50 queries per day",
                    "Basic web search"
                ),
                onSelect = { viewModel.upgradePlan(SubscriptionPlan.FREE) }
            )

            PlanCard(
                plan = SubscriptionPlan.PRO,
                price = if (isAnnual) SubscriptionPlan.PRO.priceAnnual else SubscriptionPlan.PRO.priceMonthly,
                isCurrent = userProfile.plan == SubscriptionPlan.PRO,
                isRecommended = true,
                features = listOf(
                    "Askora Ultra 3.0 deep reasoning",
                    "Unlimited Deep Web Research & Citations",
                    "Priority server-side token streaming",
                    "Zero rate limits & multimodal image queries",
                    "Continuous voice mode synthesis"
                ),
                onSelect = { viewModel.upgradePlan(SubscriptionPlan.PRO) }
            )

            PlanCard(
                plan = SubscriptionPlan.ENTERPRISE,
                price = if (isAnnual) SubscriptionPlan.ENTERPRISE.priceAnnual else SubscriptionPlan.ENTERPRISE.priceMonthly,
                isCurrent = userProfile.plan == SubscriptionPlan.ENTERPRISE,
                features = listOf(
                    "Everything in Pro",
                    "Custom fine-tuned domain models",
                    "Dedicated cloud VPC bridge",
                    "SOC2 & HIPAA compliant zero-retention"
                ),
                onSelect = { viewModel.upgradePlan(SubscriptionPlan.ENTERPRISE) }
            )
        }
    }
}

@Composable
private fun BillingOptionPill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bgColor by animateColorAsState(
        if (isSelected) LuminousCyan.copy(alpha = 0.2f) else Color.Transparent,
        label = "pillBg"
    )
    val textColor by animateColorAsState(
        if (isSelected) LuminousCyan else TextSecondary,
        label = "pillText"
    )

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun PlanCard(
    plan: SubscriptionPlan,
    price: String,
    isCurrent: Boolean,
    isRecommended: Boolean = false,
    features: List<String>,
    onSelect: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        borderColor = if (isRecommended) LuminousCyan else BorderSubtle,
        backgroundColor = if (isRecommended) SurfaceElevated.copy(alpha = 0.95f) else SurfaceDark
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = plan.title,
                    color = if (isRecommended) LuminousCyan else TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                if (isRecommended) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(LuminousCyan.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "MOST POPULAR",
                            color = LuminousCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Text(
                text = price,
                color = TextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(modifier = Modifier.height(2.dp))

            features.forEach { feature ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = VerifiedFactGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = feature,
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onSelect,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isCurrent) SurfaceHighlight else if (isRecommended) LuminousCyan else SurfaceElevated,
                    contentColor = if (isRecommended && !isCurrent) MidnightNavy else TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isRecommended) LuminousCyan else BorderSubtle,
                        RoundedCornerShape(12.dp)
                    )
            ) {
                Text(
                    text = if (isCurrent) "Current Plan" else "Activate ${plan.title}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
