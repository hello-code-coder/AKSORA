package com.example.model

enum class AnswerDepth(val label: String, val description: String) {
    SIMPLE("Simple", "Concise, direct answer with key takeaways"),
    BALANCED("Balanced", "Structured explanation with context and reasoning"),
    DEEP("Deep", "Exhaustive breakdown, trade-offs, citations & deep dive")
}

enum class MessageRole {
    USER, ASSISTANT, SYSTEM
}

enum class ModelProviderType(val displayName: String, val latencyMs: Int, val description: String) {
    ASKORA_NEO("Askora Neo 2.5", 180, "Low latency, fast reasoning & crisp direct answers"),
    ASKORA_ULTRA("Askora Ultra 3.0", 350, "Deep synthesis, multi-step problem solving & code architecture"),
    GEMINI_1_5("Gemini 1.5 Flash", 220, "Multimodal search, image & document understanding"),
    CLAUDE_BRIDGE("Claude 3.5 Sonnet", 410, "Extended reasoning, nuanced writing & citations")
}

data class Citation(
    val id: String,
    val index: Int,
    val title: String,
    val url: String,
    val domain: String,
    val snippet: String,
    val isVerifiedFact: Boolean = true,
    val credibilityScore: Int = 98
)

data class CodeSnippet(
    val language: String,
    val code: String
)

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val depth: AnswerDepth = AnswerDepth.BALANCED,
    val citations: List<Citation> = emptyList(),
    val codeBlocks: List<CodeSnippet> = emptyList(),
    val isStreaming: Boolean = false,
    val isSaved: Boolean = false,
    val feedback: Boolean? = null, // true = thumbs up, false = thumbs down
    val attachmentName: String? = null,
    val attachmentUri: String? = null
)

data class Conversation(
    val id: String,
    val title: String,
    val snippet: String,
    val updatedAt: Long = System.currentTimeMillis(),
    val messageCount: Int = 0,
    val isPinned: Boolean = false,
    val depth: AnswerDepth = AnswerDepth.BALANCED,
    val provider: ModelProviderType = ModelProviderType.ASKORA_NEO
)

data class SavedAnswer(
    val id: String,
    val messageId: String,
    val title: String,
    val summary: String,
    val content: String,
    val tags: List<String>,
    val citationsCount: Int = 0,
    val savedAt: Long = System.currentTimeMillis()
)

enum class SubscriptionPlan(val title: String, val priceMonthly: String, val priceAnnual: String) {
    FREE("Askora Free", "$0/mo", "$0/yr"),
    PRO("Askora Pro", "$19/mo", "$190/yr"),
    ENTERPRISE("Askora Enterprise", "$49/mo", "$490/yr")
}

data class UserProfile(
    val name: String = "Robin",
    val email: String = "robin@askora.ai",
    val plan: SubscriptionPlan = SubscriptionPlan.PRO,
    val queriesUsed: Int = 142,
    val deepResearchCount: Int = 38,
    val tokensProcessed: Long = 184500L,
    val reducedMotion: Boolean = false,
    val selectedProvider: ModelProviderType = ModelProviderType.ASKORA_NEO,
    val defaultDepth: AnswerDepth = AnswerDepth.BALANCED,
    val voiceAccent: String = "Cosmic Cyan (Neutral)",
    val soundEffectsEnabled: Boolean = true
)

data class ResearchStep(
    val title: String,
    val status: String, // "completed", "running", "queued"
    val detail: String
)

data class WebResearchSynthesis(
    val query: String,
    val executiveSummary: String,
    val verifiedFindings: List<String>,
    val uncertainties: List<String>,
    val citations: List<Citation>,
    val completenessScore: Int = 94
)
