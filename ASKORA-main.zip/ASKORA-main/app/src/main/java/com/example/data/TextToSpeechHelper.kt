package com.example.data

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TextToSpeechHelper(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isInitialized = true
                tts?.setPitch(1.05f)
                tts?.setSpeechRate(1.0f)
            }
        }
    }

    fun speak(text: String) {
        if (!isInitialized) return
        stop()
        _isSpeaking.value = true
        // Strip markdown syntax for natural speech
        val cleaned = text
            .replace(Regex("#+\\s*"), "")
            .replace(Regex("\\*\\*|\\*|_|`"), "")
            .replace(Regex("\\[\\d+\\]"), "")
            .take(1500)

        tts?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, "ASKORA_UTTERANCE")
    }

    fun stop() {
        if (isInitialized) {
            tts?.stop()
        }
        _isSpeaking.value = false
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }
}
