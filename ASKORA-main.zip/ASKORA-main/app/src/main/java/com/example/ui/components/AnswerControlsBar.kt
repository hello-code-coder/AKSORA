package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PromptModifier
import com.example.model.AnswerDepth
import com.example.model.ChatMessage
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.LuminousCyan
import com.example.ui.theme.MidnightDarker
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.SurfaceHighlight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VerifiedFactGreen
import com.example.ui.theme.VioletAccent

@Composable
fun DepthSelectorRow(
    selectedDepth: AnswerDepth,
    onDepthSelected: (AnswerDepth) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceDark.copy(alpha = 0.8f))
            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        AnswerDepth.entries.forEach { depth ->
            val isSelected = depth == selectedDepth
            val bgColor by animateColorAsState(
                targetValue = if (isSelected) LuminousCyan.copy(alpha = 0.16f) else Color.Transparent,
                label = "depthBg"
            )
            val textColor by animateColorAsState(
                targetValue = if (isSelected) LuminousCyan else TextSecondary,
                label = "depthText"
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(9.dp))
                    .background(bgColor)
                    .clickable { onDepthSelected(depth) }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = depth.label,
                    color = textColor,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun AnswerActionRow(
    message: ChatMessage,
    isSpeaking: Boolean,
    onReadAloud: () -> Unit,
    onStopReading: () -> Unit,
    onToggleSave: () -> Unit,
    onRegenerate: () -> Unit,
    onFeedback: (Boolean) -> Unit,
    onModifierClick: (PromptModifier) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Column(modifier = modifier.fillMaxWidth()) {
        // Quick Follow-up Pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FollowUpChip(
                label = "Simplify",
                icon = Icons.Default.TrendingUp,
                onClick = { onModifierClick(PromptModifier.SIMPLIFY) }
            )
            FollowUpChip(
                label = "Go Deeper",
                icon = Icons.Default.TrendingUp,
                onClick = { onModifierClick(PromptModifier.GO_DEEPER) }
            )
            FollowUpChip(
                label = "Give an Example",
                icon = Icons.Default.Lightbulb,
                onClick = { onModifierClick(PromptModifier.GIVE_EXAMPLE) }
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Action Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Group: Copy, Bookmark, Share, Read Aloud
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                // Copy Action
                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Askora Answer", message.content)
                        clipboard.setPrimaryClip(clip)
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy answer",
                        tint = TextSecondary,
                        modifier = Modifier.size(17.dp)
                    )
                }

                // Bookmark / Save Action
                IconButton(
                    onClick = onToggleSave,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (message.isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Save answer",
                        tint = if (message.isSaved) LuminousCyan else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Share Action
                IconButton(
                    onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "ASKORA AI Insight")
                            putExtra(Intent.EXTRA_TEXT, "${message.content}\n\n— Synthesized via ASKORA")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Insight via"))
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share answer",
                        tint = TextSecondary,
                        modifier = Modifier.size(17.dp)
                    )
                }

                // Read Aloud / TTS
                IconButton(
                    onClick = {
                        if (isSpeaking) onStopReading() else onReadAloud()
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = if (isSpeaking) "Stop reading" else "Read aloud",
                        tint = if (isSpeaking) LuminousCyan else TextSecondary,
                        modifier = Modifier.size(19.dp)
                    )
                }

                // Regenerate
                IconButton(
                    onClick = onRegenerate,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Regenerate answer",
                        tint = TextSecondary,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }

            // Right Group: Thumbs Up / Thumbs Down Feedback
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                IconButton(
                    onClick = { onFeedback(true) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (message.feedback == true) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                        contentDescription = "Helpful answer",
                        tint = if (message.feedback == true) VerifiedFactGreen else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }

                IconButton(
                    onClick = { onFeedback(false) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (message.feedback == false) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
                        contentDescription = "Unhelpful answer",
                        tint = if (message.feedback == false) VioletAccent else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FollowUpChip(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(SurfaceElevated)
            .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = LuminousCyan,
            modifier = Modifier.size(13.dp)
        )
        Text(
            text = label,
            color = TextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
