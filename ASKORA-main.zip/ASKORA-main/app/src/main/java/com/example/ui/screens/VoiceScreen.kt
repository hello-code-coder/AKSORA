package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.components.AiOrb
import com.example.ui.components.OrbState
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.LuminousCyan
import com.example.ui.theme.MidnightDarker
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent
import java.util.Locale

@Composable
fun VoiceScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.setVoiceListening(false)
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val userProfile by viewModel.userProfile.collectAsState()
    val isListening by viewModel.isVoiceListening.collectAsState()
    val voiceTranscript by viewModel.voiceTranscript.collectAsState()
    val isSpeaking by viewModel.tts.isSpeaking.collectAsState()

    var statusMessage by remember { mutableStateOf("Tap the orb or mic to speak") }

    // Waveform bounce animation
    val infiniteTransition = rememberInfiniteTransition(label = "VoiceWave")
    val waveHeight by infiniteTransition.animateFloat(
        initialValue = 8f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave"
    )

    // Android Speech Recognizer integration
    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.setVoiceListening(true)
            statusMessage = "Listening to you..."
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            try {
                speechRecognizer?.startListening(intent)
            } catch (_: Exception) {}
        } else {
            statusMessage = "Microphone access is needed for Voice Mode"
        }
    }

    DisposableEffect(Unit) {
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {
                statusMessage = "Listening..."
            }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                statusMessage = "Processing your query..."
                viewModel.setVoiceListening(false)
            }
            override fun onError(error: Int) {
                statusMessage = "Could not hear audio. Tap to try again."
                viewModel.setVoiceListening(false)
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()
                if (!text.isNullOrBlank()) {
                    viewModel.submitVoiceQuery(text)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                matches?.firstOrNull()?.let { statusMessage = it }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        onDispose {
            speechRecognizer?.destroy()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        SurfaceElevated.copy(alpha = 0.5f),
                        MidnightNavy,
                        MidnightDarker
                    )
                )
            )
            .padding(20.dp)
    ) {
        // Top Bar Controls (Close button on left, menu on right - matches screenshot)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(SurfaceElevated.copy(alpha = 0.8f))
                    .clickable {
                        viewModel.setVoiceListening(false)
                        viewModel.navigateBack()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close voice mode",
                    tint = TextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }

            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(SurfaceElevated.copy(alpha = 0.8f))
                    .clickable { viewModel.navigateTo(Screen.PROFILE) },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Settings",
                    tint = TextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Center Content: Glowing Orb & Greeting (Exact layout from user screenshot)
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AiOrb(
                size = 230.dp,
                state = when {
                    isListening -> OrbState.LISTENING
                    isSpeaking -> OrbState.STREAMING
                    else -> OrbState.IDLE
                },
                onClick = {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            )

            Spacer(modifier = Modifier.height(36.dp))

            Text(
                text = "Hello ${userProfile.name}",
                color = TextSecondary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isListening) "I'm listening..."
                else if (isSpeaking) "Speaking response..."
                else "How can I help\nyou today?",
                color = TextPrimary,
                fontSize = 30.sp,
                lineHeight = 36.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Dynamic live transcript or tip
            Text(
                text = voiceTranscript.ifBlank { statusMessage },
                color = LuminousCyan,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            // Audio waveform reactive animation if listening or speaking
            if (isListening || isSpeaking) {
                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(7) { index ->
                        val barHeight = when (index % 3) {
                            0 -> waveHeight.dp
                            1 -> (waveHeight * 0.7f).dp
                            else -> (waveHeight * 1.3f).dp
                        }
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(barHeight)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    if (index % 2 == 0) LuminousCyan else VioletAccent
                                )
                        )
                    }
                }
            }
        }

        // Bottom Composer Pill (Matches the user screenshot)
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 24.dp)
                .clip(RoundedCornerShape(32.dp))
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            LuminousCyan.copy(alpha = 0.5f),
                            VioletAccent.copy(alpha = 0.3f),
                            LuminousCyan.copy(alpha = 0.4f)
                        )
                    ),
                    shape = RoundedCornerShape(32.dp)
                )
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            SurfaceElevated.copy(alpha = 0.95f),
                            SurfaceDark.copy(alpha = 0.98f)
                        )
                    ),
                    shape = RoundedCornerShape(32.dp)
                )
                .clickable {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isListening) "Tap to finish speaking..." else "Ask anything...",
                    color = if (isListening) LuminousCyan else TextMuted,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Normal
                )

                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = "Voice waveform",
                    tint = LuminousCyan,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
