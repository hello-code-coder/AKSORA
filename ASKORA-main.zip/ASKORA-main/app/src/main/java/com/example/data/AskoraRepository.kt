package com.example.data

import com.example.data.local.AskoraDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.Converters
import com.example.data.local.ConversationEntity
import com.example.data.local.SavedAnswerEntity
import com.example.model.AnswerDepth
import com.example.model.ChatMessage
import com.example.model.Conversation
import com.example.model.MessageRole
import com.example.model.ModelProviderType
import com.example.model.SavedAnswer
import com.example.model.SubscriptionPlan
import com.example.model.UserProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import java.util.UUID

class AskoraRepository(
    private val dao: AskoraDao,
    private val engine: AskoraAiEngine
) {
    private val converters = Converters()

    // In-memory reactive user profile state with persistence hooks
    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    fun updateUserProfile(update: (UserProfile) -> UserProfile) {
        _userProfile.value = update(_userProfile.value)
    }

    // Conversations Flow
    val allConversations: Flow<List<Conversation>> = dao.getAllConversations().map { entities ->
        entities.map { it.toDomain() }
    }

    fun getMessages(conversationId: String): Flow<List<ChatMessage>> =
        dao.getMessagesForConversation(conversationId).map { entities ->
            entities.map { it.toDomain(converters) }
        }

    val allSavedAnswers: Flow<List<SavedAnswer>> = dao.getAllSavedAnswers().map { entities ->
        entities.map { it.toDomain(converters) }
    }

    suspend fun getOrCreateConversation(id: String?, initialTitle: String = "New Understanding"): Conversation {
        if (!id.isNullOrBlank()) {
            val existing = dao.getConversationById(id)
            if (existing != null) return existing.toDomain()
        }
        val newId = id ?: UUID.randomUUID().toString()
        val conversation = Conversation(
            id = newId,
            title = initialTitle,
            snippet = "Beginning inquiry...",
            updatedAt = System.currentTimeMillis(),
            messageCount = 0,
            isPinned = false,
            depth = _userProfile.value.defaultDepth,
            provider = _userProfile.value.selectedProvider
        )
        dao.insertConversation(conversation.toEntity())
        return conversation
    }

    suspend fun sendUserMessage(
        conversationId: String,
        content: String,
        depth: AnswerDepth = _userProfile.value.defaultDepth,
        attachmentName: String? = null,
        attachmentUri: String? = null
    ): ChatMessage {
        val userMsgId = UUID.randomUUID().toString()
        val userMsg = ChatMessage(
            id = userMsgId,
            conversationId = conversationId,
            role = MessageRole.USER,
            content = content,
            timestamp = System.currentTimeMillis(),
            depth = depth,
            attachmentName = attachmentName,
            attachmentUri = attachmentUri
        )
        dao.insertMessage(userMsg.toEntity(converters))

        // Update conversation summary
        val conv = dao.getConversationById(conversationId)
        if (conv != null) {
            val title = if (conv.messageCount == 0) {
                if (content.length > 32) content.take(30) + "..." else content
            } else conv.title

            dao.updateConversation(
                conv.copy(
                    title = title,
                    snippet = if (content.length > 60) content.take(57) + "..." else content,
                    updatedAt = System.currentTimeMillis(),
                    messageCount = conv.messageCount + 1,
                    depth = depth.name
                )
            )
        }

        // Increment usage statistics
        _userProfile.value = _userProfile.value.copy(
            queriesUsed = _userProfile.value.queriesUsed + 1,
            tokensProcessed = _userProfile.value.tokensProcessed + (content.length * 3L)
        )

        return userMsg
    }

    suspend fun streamAssistantResponse(
        conversationId: String,
        prompt: String,
        depth: AnswerDepth,
        modifier: PromptModifier? = null,
        onPartialUpdate: (String) -> Unit
    ): ChatMessage {
        val assistantMsgId = UUID.randomUUID().toString()
        val initialMsg = ChatMessage(
            id = assistantMsgId,
            conversationId = conversationId,
            role = MessageRole.ASSISTANT,
            content = "",
            timestamp = System.currentTimeMillis(),
            depth = depth,
            isStreaming = true
        )
        dao.insertMessage(initialMsg.toEntity(converters))

        var accumulated = ""
        engine.streamResponse(prompt, depth, modifier).collect { chunk ->
            accumulated = chunk
            onPartialUpdate(accumulated)
            dao.updateMessage(
                initialMsg.copy(
                    content = accumulated,
                    isStreaming = true
                ).toEntity(converters)
            )
        }

        val finalized = engine.finalizeResponse(prompt, depth, modifier)
        val finalMessage = ChatMessage(
            id = assistantMsgId,
            conversationId = conversationId,
            role = MessageRole.ASSISTANT,
            content = finalized.fullText,
            timestamp = System.currentTimeMillis(),
            depth = depth,
            citations = finalized.citations,
            codeBlocks = finalized.codeBlocks,
            isStreaming = false
        )
        dao.updateMessage(finalMessage.toEntity(converters))

        // Update conversation snippet and count
        val conv = dao.getConversationById(conversationId)
        if (conv != null) {
            val snippet = finalized.fullText.take(60).replace("\n", " ") + "..."
            dao.updateConversation(
                conv.copy(
                    snippet = snippet,
                    updatedAt = System.currentTimeMillis(),
                    messageCount = conv.messageCount + 1
                )
            )
        }

        return finalMessage
    }

    suspend fun toggleSaveMessage(message: ChatMessage): Boolean {
        val newSavedState = !message.isSaved
        dao.setMessageSaved(message.id, newSavedState)

        if (newSavedState) {
            val savedAnswer = SavedAnswer(
                id = UUID.randomUUID().toString(),
                messageId = message.id,
                title = message.content.lines().firstOrNull { it.isNotBlank() }
                    ?.replace(Regex("#+\\s*"), "")
                    ?.take(40) ?: "Saved Answer",
                summary = message.content.take(120) + "...",
                content = message.content,
                tags = listOf(message.depth.label, "AI Verified"),
                citationsCount = message.citations.size,
                savedAt = System.currentTimeMillis()
            )
            dao.insertSavedAnswer(savedAnswer.toEntity(converters))
        } else {
            dao.deleteSavedAnswerByMessageId(message.id)
        }
        return newSavedState
    }

    suspend fun setFeedback(messageId: String, feedback: Boolean?) {
        dao.setMessageFeedback(messageId, feedback)
    }

    suspend fun togglePinConversation(conversation: Conversation) {
        val updated = conversation.copy(isPinned = !conversation.isPinned)
        dao.updateConversation(updated.toEntity())
    }

    suspend fun deleteConversation(id: String) {
        dao.deleteMessagesForConversation(id)
        dao.deleteConversation(id)
    }

    suspend fun purgeAllUserData() {
        dao.clearAllMessages()
        dao.clearAllConversations()
        dao.clearAllSavedAnswers()
        _userProfile.value = _userProfile.value.copy(
            queriesUsed = 0,
            deepResearchCount = 0,
            tokensProcessed = 0L
        )
    }

    suspend fun upgradeSubscription(plan: SubscriptionPlan) {
        _userProfile.value = _userProfile.value.copy(plan = plan)
    }

    // Mapping helpers
    private fun ConversationEntity.toDomain() = Conversation(
        id = id,
        title = title,
        snippet = snippet,
        updatedAt = updatedAt,
        messageCount = messageCount,
        isPinned = isPinned,
        depth = runCatching { AnswerDepth.valueOf(depth) }.getOrDefault(AnswerDepth.BALANCED),
        provider = runCatching { ModelProviderType.valueOf(provider) }.getOrDefault(ModelProviderType.ASKORA_NEO)
    )

    private fun Conversation.toEntity() = ConversationEntity(
        id = id,
        title = title,
        snippet = snippet,
        updatedAt = updatedAt,
        messageCount = messageCount,
        isPinned = isPinned,
        depth = depth.name,
        provider = provider.name
    )

    private fun ChatMessageEntity.toDomain(converters: Converters) = ChatMessage(
        id = id,
        conversationId = conversationId,
        role = runCatching { MessageRole.valueOf(role) }.getOrDefault(MessageRole.ASSISTANT),
        content = content,
        timestamp = timestamp,
        depth = runCatching { AnswerDepth.valueOf(depth) }.getOrDefault(AnswerDepth.BALANCED),
        citations = converters.toCitations(citationsJson),
        codeBlocks = converters.toCodeBlocks(codeBlocksJson),
        isStreaming = isStreaming,
        isSaved = isSaved,
        feedback = feedback,
        attachmentName = attachmentName,
        attachmentUri = attachmentUri
    )

    private fun ChatMessage.toEntity(converters: Converters) = ChatMessageEntity(
        id = id,
        conversationId = conversationId,
        role = role.name,
        content = content,
        timestamp = timestamp,
        depth = depth.name,
        citationsJson = converters.fromCitations(citations),
        codeBlocksJson = converters.fromCodeBlocks(codeBlocks),
        isStreaming = isStreaming,
        isSaved = isSaved,
        feedback = feedback,
        attachmentName = attachmentName,
        attachmentUri = attachmentUri
    )

    private fun SavedAnswerEntity.toDomain(converters: Converters) = SavedAnswer(
        id = id,
        messageId = messageId,
        title = title,
        summary = summary,
        content = content,
        tags = converters.toStringList(tagsJson),
        citationsCount = citationsCount,
        savedAt = savedAt
    )

    private fun SavedAnswer.toEntity(converters: Converters) = SavedAnswerEntity(
        id = id,
        messageId = messageId,
        title = title,
        summary = summary,
        content = content,
        tagsJson = converters.fromStringList(tags),
        citationsCount = citationsCount,
        savedAt = savedAt
    )
}
