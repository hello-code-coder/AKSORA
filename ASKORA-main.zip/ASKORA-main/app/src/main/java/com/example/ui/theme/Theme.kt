package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val AskoraDarkColorScheme = darkColorScheme(
    primary = LuminousCyan,
    onPrimary = MidnightNavy,
    primaryContainer = SurfaceHighlight,
    onPrimaryContainer = LuminousCyan,
    secondary = VioletAccent,
    onSecondary = MidnightNavy,
    secondaryContainer = SurfaceElevated,
    onSecondaryContainer = VioletAccent,
    tertiary = CyanGlow,
    onTertiary = MidnightNavy,
    background = MidnightNavy,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    outlineVariant = GlassBorder,
    error = ErrorRose,
    onError = TextPrimary
)

@Composable
fun AskoraTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = AskoraDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = MidnightNavy.toArgb()
                window.navigationBarColor = MidnightNavy.toArgb()
                val insetsController = WindowCompat.getInsetsController(window, view)
                insetsController.isAppearanceLightStatusBars = false
                insetsController.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
