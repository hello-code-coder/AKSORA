package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ASKORA Futuristic Theme Colors
// Deep midnight navy base
val MidnightNavy = Color(0xFF080D1B)
val MidnightDarker = Color(0xFF050811)
val SurfaceDark = Color(0xFF0E1626)
val SurfaceElevated = Color(0xFF131E33)
val SurfaceGlass = Color(0x99131E33)
val SurfaceHighlight = Color(0xFF1C2C47)

// Luminous futuristic accents
val LuminousCyan = Color(0xFF72E6FF)
val CyanGlow = Color(0xFF38BDF8)
val CyanDeep = Color(0xFF0284C7)
val VioletAccent = Color(0xFF8B7CFF)
val VioletDeep = Color(0xFF6366F1)
val ElectricIndigo = Color(0xFF4F46E5)
val CosmicPurple = Color(0xFFA855F7)

// Border & Divider
val GlassBorder = Color(0x3372E6FF)
val GlassBorderMuted = Color(0x1F8B7CFF)
val BorderSubtle = Color(0xFF1E2D4A)

// Text tokens
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Functional indicators
val VerifiedFactGreen = Color(0xFF10B981)
val UncertaintyAmber = Color(0xFFF59E0B)
val ErrorRose = Color(0xFFF43F5E)
